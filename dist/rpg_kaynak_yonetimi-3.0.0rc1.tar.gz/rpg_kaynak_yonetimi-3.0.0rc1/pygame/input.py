"""Input mapping for the playable slice.

The module intentionally knows only about pygame-like event objects.  This
keeps gameplay screens easy to exercise with a tiny fake backend in tests.
"""

from dataclasses import dataclass, field


@dataclass
class InputState:
    """Frame input translated into stable, backend-independent actions."""

    actions: set[str] = field(default_factory=set)
    text: str = ""
    quit_requested: bool = False

    def pressed(self, action: str) -> bool:
        return action in self.actions


class InputMapper:
    """Translate keyboard/window events into gameplay actions."""

    def __init__(self, backend=None) -> None:
        self.backend = backend

    def collect(self, events) -> InputState:
        state = InputState()
        for event in events:
            event_type = getattr(event, "type", None)
            quit_type = getattr(self.backend, "QUIT", "QUIT")
            keydown_type = getattr(self.backend, "KEYDOWN", "KEYDOWN")
            if event_type == quit_type or event_type == "QUIT":
                state.quit_requested = True
                continue
            if event_type != keydown_type and event_type != "KEYDOWN":
                continue
            key = self._key_name(getattr(event, "key", None))
            action = {
                "escape": "back",
                "return": "confirm",
                "space": "wait",
                "g": "gather",
                "c": "craft",
                "i": "inventory",
                "p": "character",
                "m": "market",
                "d": "dialogue",
                "b": "combat",
                "n": "character_creation",
                "w": "world",
                "q": "quit",
                "left": "left",
                "right": "right",
                "up": "up",
                "down": "down",
                "f5": "save",
                "f9": "load",
                "x": "map",
                "l": "local_map",
            }.get(key)
            if action:
                state.actions.add(action)
            if key.isdigit():
                state.actions.add(f"slot:{key}")
        return state

    def _key_name(self, key) -> str:
        if isinstance(key, str):
            return key.lower()
        names = {
            getattr(self.backend, "K_ESCAPE", object()): "escape",
            getattr(self.backend, "K_RETURN", object()): "return",
            getattr(self.backend, "K_SPACE", object()): "space",
            getattr(self.backend, "K_LEFT", object()): "left",
            getattr(self.backend, "K_RIGHT", object()): "right",
            getattr(self.backend, "K_UP", object()): "up",
            getattr(self.backend, "K_DOWN", object()): "down",
        }
        if self.backend is not None:
            for letter in "gc ipwqxl".replace(" ", ""):
                names[getattr(self.backend, f"K_{letter}", object())] = letter
            names[getattr(self.backend, "K_F5", object())] = "f5"
            names[getattr(self.backend, "K_F9", object())] = "f9"
        return names.get(key, "")
