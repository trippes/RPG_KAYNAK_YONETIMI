class InventoryScreen:
    def __init__(self, service, inventory_id="player"):
        self.service = service
        self.inventory_id = inventory_id

    def handle(self, state):
        if state.pressed("world") or state.pressed("back"):
            return "world"
        if state.pressed("character"):
            return "character"
        return None

    def render(self, renderer):
        snapshot = self.service.inventory(self.inventory_id)
        renderer.frame("Envanter")
        renderer.hud(self.service)
        renderer.panel(renderer.pg.Rect(70, 130, 820, 350))
        renderer.text("Oyuncu çantası", 98, 160, title=True)
        if not snapshot.stocks:
            renderer.text("Çanta boş", 100, 230, (155, 172, 196))
        for index, (resource, amount, unit) in enumerate(snapshot.stocks):
            renderer.panel(renderer.pg.Rect(96, 210 + index * 54, 760, 42), (38, 49, 69), (62, 78, 101))
            renderer.text(resource, 114, 220 + index * 54, title=True)
            renderer.text(f"{amount} {unit}", 700, 225 + index * 54, (220, 190, 120))
        renderer.footer("W Dünya   P Karakter   Esc Dünya")
