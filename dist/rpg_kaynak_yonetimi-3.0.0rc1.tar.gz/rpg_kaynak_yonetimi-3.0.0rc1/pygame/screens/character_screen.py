class CharacterScreen:
    def __init__(self, service):
        self.service = service

    def handle(self, state):
        if state.pressed("world") or state.pressed("back"):
            return "world"
        if state.pressed("inventory"):
            return "inventory"
        return None

    def render(self, renderer):
        snapshot = self.service.state()
        renderer.frame("Karakter")
        renderer.hud(self.service)
        renderer.panel(renderer.pg.Rect(70, 130, 820, 350))
        if not snapshot.actors:
            renderer.text("Karakter kaydı bulunamadı.", 100, 190)
        for index, actor in enumerate(snapshot.actors):
            stats = self.service.actor_stats(actor.actor_id)
            if stats is None:
                line = f"{actor.actor_id} — {actor.role} — {'aktif' if actor.active else 'pasif'}"
            else:
                line = f"{stats['name']} — Lv {stats['level']} — HP {stats['current_hit_points']}/{stats['max_hit_points']}"
                detail = "  ".join(f"{key[:3].upper()} {value}" for key, value in stats["attributes"].items())
                renderer.text(detail, 120, 225 + index * 42, (190, 202, 220))
            renderer.text(line, 100, 195 + index * 42, title=index == 0)
        active_quests = self.service.application.holder.current.quest_log.active()
        if active_quests:
            renderer.text("Aktif görevler", 100, 360, title=True)
            for index, quest in enumerate(active_quests[:3]):
                renderer.text(f"{quest.title} — {quest.state.value}", 120, 400 + index * 28)
        renderer.footer("W Dünya   I Envanter   Esc Dünya")
