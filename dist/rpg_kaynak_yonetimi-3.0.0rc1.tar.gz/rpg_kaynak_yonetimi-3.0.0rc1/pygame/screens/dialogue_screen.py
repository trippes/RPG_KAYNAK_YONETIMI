class DialogueScreen:
    def __init__(self, service):
        self.service = service
        self.node = None
        self.message = "D ile konuşmayı başlat."
        self.context = None
        self.selected = 0

    def _open_default(self):
        bundle = self.service.application.holder.current
        actors = bundle.actors.actors()
        npcs = bundle.social.npcs.all()
        dialogues = tuple(sorted(bundle.social.dialogues))
        if not actors or not npcs or not dialogues:
            self.message = "Konuşulacak NPC veya diyalog bulunamadı."
            return
        try:
            self.context = (actors[0].actor_id, npcs[0].npc_id, dialogues[0])
            self.node = self.service.talk_to_npc(*self.context)
        except (KeyError, ValueError, RuntimeError) as error:
            self.message = str(error)

    def handle(self, state):
        if self.node is not None and self.node.choices:
            if state.pressed("up"): self.selected = (self.selected - 1) % len(self.node.choices)
            if state.pressed("down"): self.selected = (self.selected + 1) % len(self.node.choices)
            if state.pressed("confirm"):
                actor_id, npc_id, dialogue_id = self.context
                try:
                    choice = self.node.choices[self.selected]
                    self.node = self.service.choose_dialogue(actor_id, npc_id, dialogue_id, self.node.node_id, choice.choice_id)
                    self.message = "Seçim yapıldı."
                except (KeyError, ValueError, RuntimeError) as error:
                    self.message = str(error)
        elif state.pressed("confirm") and self.node is None:
            self._open_default()
        elif state.pressed("back") or state.pressed("world"):
            return "world"
        return None

    def render(self, renderer):
        renderer.frame("Diyalog")
        renderer.hud(self.service)
        renderer.panel(renderer.pg.Rect(70, 130, 820, 350))
        if self.node is None:
            renderer.wrapped_text(self.message, 100, 190, 740)
        else:
            renderer.text(self.node.speaker_id, 100, 170, title=True)
            renderer.wrapped_text(self.node.text, 100, 225, 740)
            for index, choice in enumerate(self.node.choices):
                marker = "▶ " if index == self.selected else "  "
                renderer.text(f"{marker}{choice.text}", 120, 310 + index * 36, (220, 225, 235) if index == self.selected else (170, 185, 205))
        renderer.footer("Enter Konuş/Seç   ↑/↓ Seçim   Esc Dünya")
