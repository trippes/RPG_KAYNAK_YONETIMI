class MarketScreen:
    def __init__(self, service):
        self.service = service
        self.selected = 0
        self.message = "Enter ile seçili teklifi satın al."

    def handle(self, state):
        offers = self.service.market_offers()
        if offers and (state.pressed("up") or state.pressed("down")):
            self.selected = (self.selected + (1 if state.pressed("down") else -1)) % len(offers)
        if offers and state.pressed("confirm"):
            offer = offers[self.selected]
            try:
                self.service.buy_offer(offer.offer_id, "hero", "player", quantity=1)
                self.message = f"1 {offer.resource_type.value} satın alındı."
            except (KeyError, ValueError, RuntimeError) as error:
                self.message = f"Satın alma başarısız: {error}"
        if state.pressed("world") or state.pressed("back"):
            return "world"
        if state.pressed("character"):
            return "character"
        return None

    def render(self, renderer):
        renderer.frame("Pazar")
        renderer.hud(self.service)
        renderer.panel(renderer.pg.Rect(70, 130, 820, 350))
        renderer.text("Satın alınabilir teklifler", 98, 160, title=True)
        offers = self.service.market_offers()
        if not offers:
            renderer.text("Aktif market teklifi yok.", 100, 230)
        for index, offer in enumerate(offers):
            marker = "▶ " if index == self.selected else "  "
            renderer.text(
                f"{marker}{offer.offer_id} — {offer.quantity} {offer.resource_type.value} — "
                f"{offer.unit_price.amount} {offer.unit_price.currency.value}",
                100, 220 + index * 42, title=index == self.selected,
            )
        try:
            balance = self.service.balance("hero", "gold").amount
            renderer.text(f"Altın: {balance}", 100, 410, (220, 190, 120))
        except (KeyError, ValueError):
            pass
        renderer.text(self.message, 100, 455, (220, 190, 120))
        renderer.footer("↑/↓ Teklif seç   Enter Satın al   W Dünya   P Karakter   Esc Dünya")
