from resources import Quantity, ResourceUnit


class WorldScreen:
    def __init__(self, service, inventory_id="player"):
        self.service = service
        self.inventory_id = inventory_id
        self.selected = 0
        self.message = "G: topla   C: üret   Space: zamanı ilerlet   I/P: ekran"

    def _current_location(self, actors):
        if not actors:
            return None, None
        world_map = self.service.application.holder.current.movement.map_for(actors[0].world_id)
        if world_map is None:
            return None, None
        return world_map, world_map.get(actors[0].location_id)

    def _has_activity(self, location, activity):
        return location is not None and activity in location.activities

    def handle(self, state):
        snapshot = self.service.state()
        nodes = snapshot.nodes
        actors = snapshot.actors
        if actors and (state.pressed("right") or state.pressed("left")):
            actor = actors[0]
            world_map = self.service.application.holder.current.movement.map_for(actor.world_id)
            if world_map is not None:
                locations = world_map.locations()
                current = next((index for index, location in enumerate(locations) if location.location_id == actor.location_id), 0)
                destination = locations[(current + (1 if state.pressed("right") else -1)) % len(locations)]
                try:
                    self.service.move_actor(actor.actor_id, destination.location_id)
                    self.service.advance_by(1)
                    self.message = f"{destination.name} konumuna gidildi."
                except (KeyError, ValueError, RuntimeError) as error:
                    self.message = f"Seyahat başarısız: {error}"
        if nodes:
            if state.pressed("up"):
                self.selected = (self.selected - 1) % len(nodes)
            if state.pressed("down"):
                self.selected = (self.selected + 1) % len(nodes)
            node = nodes[self.selected]
            if state.pressed("gather"):
                if not self._has_activity(self._current_location(actors)[1], "gather"):
                    self.message = "Bu lokasyonda toplanacak kaynak yok."
                    return None
                try:
                    actor = actors[0] if actors else None
                    if actor is not None and node.location_id is not None:
                        self.service.start_gathering_at_location(actor.actor_id, node.location_id, node.node_id, self.inventory_id, Quantity(1, ResourceUnit(node.quantity[1])))
                    else:
                        self.service.collect(node.node_id, self.inventory_id, Quantity(1, ResourceUnit(node.quantity[1])))
                    self.message = f"{node.resource_type} toplandı."
                except (KeyError, ValueError, RuntimeError) as error:
                    self.message = f"Toplama başarısız: {error}"
            if state.pressed("craft"):
                try:
                    self.service.start_production("campfire", self.inventory_id, "campfire")
                    self.message = "Üretim başladı; Space ile zamanı ilerlet."
                except (KeyError, ValueError, RuntimeError) as error:
                    self.message = f"Üretim başarısız: {error}"
        if state.pressed("wait"):
            try:
                self.service.advance_by(1)
                self.message = "Bir tick ilerletildi."
            except RuntimeError as error:
                self.message = str(error)
        if state.pressed("inventory"):
            return "inventory"
        if state.pressed("character"):
            return "character"
        if state.pressed("market"):
            if not self._has_activity(self._current_location(actors)[1], "market"):
                self.message = "Pazar yalnızca yerleşim yerlerinde kullanılabilir."
                return None
            return "market"
        if state.pressed("dialogue"):
            if not self._has_activity(self._current_location(actors)[1], "dialogue"):
                self.message = "Bu lokasyonda konuşulacak NPC yok."
                return None
            return "dialogue"
        if state.pressed("combat"):
            if not self._has_activity(self._current_location(actors)[1], "combat"):
                self.message = "Bu lokasyonda karşılaşma yok."
                return None
            return "combat"
        if state.pressed("character_creation"):
            return "character_creation"
        if state.pressed("map"):
            return "map"
        if state.pressed("local_map"):
            return "local_map"
        if state.pressed("back"):
            return "menu"
        return None

    def render(self, renderer):
        snapshot = self.service.state()
        renderer.frame(f"Dünya — {snapshot.world_id}", snapshot.simulation_tick)
        renderer.hud(self.service)
        actors = snapshot.actors
        current_location = actors[0].location_id if actors else None
        map_rect = renderer.pg.Rect(24, 130, 620, 350)
        renderer.panel(map_rect, (22, 30, 43), (62, 78, 101))
        renderer.text("Dünya haritası", 48, 150, title=True)
        world_map = None
        if actors:
            world_map = self.service.application.holder.current.movement.map_for(actors[0].world_id)
        if world_map is not None:
            renderer.world_map(world_map, current_location_id=current_location, rect=map_rect)
        else:
            renderer.text("Bu dünyada harita bulunamadı.", 52, 220, (155, 172, 196))

        renderer.panel(renderer.pg.Rect(670, 130, 250, 350))
        renderer.text("Lokasyon özeti", 694, 150, title=True)
        location = world_map.get(current_location) if world_map and current_location else None
        renderer.text(location.name if location else "Bilinmeyen", 694, 204, (220, 190, 120))
        if location:
            renderer.text(f"{location.location_type} bölgesi", 694, 232, (155, 172, 196))
            renderer.wrapped_text(location.description, 694, 260, 205, (190, 202, 220), line_height=24)
        if actors and current_location:
            try:
                interaction = self.service.interact_with_location(actors[0].actor_id, current_location)
                renderer.text(f"Kaynak: {len(interaction.resource_node_ids)}", 694, 240, (190, 202, 220))
                renderer.text(f"Aktör: {len(interaction.actor_ids)}", 694, 268, (190, 202, 220))
            except (KeyError, RuntimeError, ValueError):
                pass
        renderer.text("Burada yapılabilir", 694, 330, title=True)
        if location and location.activities:
            labels = {"dialogue": "D Konuş", "market": "M Pazar", "gather": "G Topla", "combat": "B Savaş", "travel": "←/→ Seyahat"}
            renderer.text("  ".join(labels.get(item, item) for item in location.activities), 694, 364, (220, 190, 120))
        renderer.text("Aktif görev", 694, 398, title=True)
        quests = self.service.application.holder.current.quest_log.active()
        if quests:
            quest = quests[0]
            renderer.text(quest.title, 694, 426, (220, 190, 120))
            for index, objective in enumerate(quest.objectives):
                marker = "✓" if objective.completed else "○"
                renderer.text(f"{marker} {objective.description}", 694, 450 + index * 22, (190, 202, 220))
        else:
            renderer.text("Aktif görev yok.", 694, 426, (155, 172, 196))
        renderer.text(self.message, 28, 500, (220, 190, 120))
        renderer.footer("X Dünya haritası   L Yerel harita   ←/→ Seyahat   G Topla   D Diyalog   M Pazar   B Savaş")
