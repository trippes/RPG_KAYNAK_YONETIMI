"""Pygame application shell for the playable vertical slice."""

from pathlib import Path

from .input import InputMapper
from .renderer import Renderer
from .screens.character_screen import CharacterScreen
from .screens.inventory_screen import InventoryScreen
from .screens.main_menu import MainMenu
from .screens.map_screen import MapScreen
from .screens.local_map_screen import LocalMapScreen
from .screens.world_screen import WorldScreen
from .screens.market_screen import MarketScreen
from .screens.dialogue_screen import DialogueScreen
from .screens.combat_screen import CombatScreen
from .screens.character_creation import CharacterCreationScreen


class GameWindow:
    """Own the frame loop and route input between screens.

    ``backend`` is injected so tests can use a fake pygame-compatible module.
    """

    def __init__(self, service, backend, *, width=960, height=640, title="Eldoria", save_path="save/eldoria_save.json"):
        self.service = service
        self.pg = backend
        self.width, self.height = width, height
        # The adapter is intentionally import-safe, so initialize pygame only
        # when an actual window is created.
        if hasattr(backend, "init"):
            backend.init()
        if hasattr(backend, "font") and hasattr(backend.font, "init"):
            backend.font.init()
        self.screen = backend.display.set_mode((width, height))
        backend.display.set_caption(title)
        self.renderer = Renderer(backend, self.screen, width, height)
        self.input = InputMapper(backend)
        self.screens = {
            "menu": MainMenu(),
            "world": WorldScreen(service),
            "map": MapScreen(service),
            "local_map": LocalMapScreen(service),
            "inventory": InventoryScreen(service),
            "character": CharacterScreen(service),
            "market": MarketScreen(service),
            "dialogue": DialogueScreen(service),
            "combat": CombatScreen(service),
            "character_creation": CharacterCreationScreen(service),
        }
        self.current = "menu"
        self.running = False
        self.save_path = Path(save_path)
        self.notice = ""

    def step(self, events=()):
        state = self.input.collect(events)
        if state.quit_requested:
            self.running = False
            return
        if state.pressed("quit"):
            self.running = False
            return
        if state.pressed("save"):
            try:
                self.save_path.parent.mkdir(parents=True, exist_ok=True)
                self.service.save(self.save_path)
                self.notice = f"Oyun kaydedildi: {self.save_path}"
            except (OSError, KeyError, ValueError, RuntimeError) as error:
                self.notice = f"Kaydetme başarısız: {error}"
        if state.pressed("load"):
            try:
                self.service.load(self.save_path)
                self.notice = f"Oyun yüklendi: {self.save_path}"
            except (OSError, KeyError, ValueError, RuntimeError) as error:
                self.notice = f"Yükleme başarısız: {error}"
        next_screen = self.screens[self.current].handle(state)
        if next_screen == "quit":
            self.running = False
            return
        if next_screen in self.screens:
            self.current = next_screen
        self.screens[self.current].render(self.renderer)
        if self.notice:
            self.renderer.error(self.notice)

    def run(self, *, fps=60):
        self.running = True
        clock = self.pg.time.Clock()
        while self.running:
            self.step(self.pg.event.get())
            self.pg.display.flip()
            clock.tick(fps)
        self.pg.quit()


def launch(service, backend=None, **kwargs):
    """Create and run a window; importing this module remains headless-safe."""
    if backend is None:
        raise RuntimeError(
            "Pygame backend bulunamadı. `pip install pygame` sonrası "
            "launch(service, backend=pygame) kullanın."
        )
    window = GameWindow(service, backend, **kwargs)
    window.run()
    return window
