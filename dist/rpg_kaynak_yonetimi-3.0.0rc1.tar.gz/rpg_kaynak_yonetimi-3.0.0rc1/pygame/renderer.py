"""Small retained-style renderer used by the vertical slice screens."""


class Renderer:
    def __init__(self, backend, surface, width: int, height: int) -> None:
        self.pg = backend
        self.surface = surface
        self.width = width
        self.height = height
        self.font = backend.font.Font(None, 24)
        self.title_font = backend.font.Font(None, 42)

    def clear(self, color=(18, 22, 32)):
        self.surface.fill(color)

    def text(self, value, x, y, color=(235, 238, 245), *, title=False):
        font = self.title_font if title else self.font
        self.surface.blit(font.render(str(value), True, color), (x, y))

    def wrapped_text(self, value, x, y, max_width, color=(235, 238, 245), *, line_height=30):
        """Render readable word-wrapped text and return the next y position."""
        words = str(value).split()
        lines = []
        current = ""
        for word in words:
            candidate = f"{current} {word}".strip()
            if current and self.font.size(candidate)[0] > max_width:
                lines.append(current)
                current = word
            else:
                current = candidate
        if current:
            lines.append(current)
        for line in lines:
            self.text(line, x, y, color)
            y += line_height
        return y

    def panel(self, rect, color=(31, 39, 55), border=(76, 92, 120)):
        self.pg.draw.rect(self.surface, color, rect, border_radius=8)
        self.pg.draw.rect(self.surface, border, rect, 2, border_radius=8)

    def button(self, rect, label, selected=False):
        self.panel(rect, (55, 75, 105) if selected else (38, 49, 69))
        self.text(label, rect.x + 16, rect.y + 11)

    def frame(self, title, tick=None):
        self.clear()
        self.text(title, 28, 22, title=True)
        if tick is not None:
            self.text(f"Tick {tick}", self.width - 150, 34, (155, 172, 196))

    def hud(self, service, actor_id="hero"):
        """Render the compact status strip shared by gameplay screens."""
        snapshot = service.state()
        stats = service.actor_stats(actor_id)
        location = "Bilinmeyen konum"
        if stats is not None:
            actor = service.actor(actor_id)
            if actor is not None and actor.location_id:
                world_map = service.application.holder.current.movement.map_for(actor.world_id)
                if world_map is not None and world_map.get(actor.location_id) is not None:
                    location = world_map.get(actor.location_id).name
        hp = "HP —"
        if stats is not None:
            hp = f"HP {stats['current_hit_points']}/{stats['max_hit_points']}"
        try:
            gold = service.balance(actor_id, "gold").amount
        except (KeyError, ValueError):
            gold = 0
        self.panel(self.pg.Rect(24, 72, self.width - 48, 42), (25, 33, 47), (62, 78, 101))
        self.text(f"{stats['name'] if stats else actor_id}  •  {hp}  •  {gold} altın", 40, 82, (220, 225, 235))
        self.text(f"{location}  •  Tick {snapshot.simulation_tick}", self.width - 330, 82, (170, 185, 205))

    def footer(self, value):
        self.text(value, 28, self.height - 28, (155, 172, 196))

    def map_edge(self, start, end, color=(76, 92, 120), width=4):
        self.pg.draw.line(self.surface, color, start, end, width)

    def map_node(self, position, color=(55, 75, 105), *, selected=False, current=False):
        radius = 23 if selected else 18
        self.pg.draw.circle(self.surface, color, position, radius)
        border = (245, 210, 120) if current else (155, 172, 196)
        self.pg.draw.circle(self.surface, border, position, radius, 3)

    def world_map(self, world_map, current_location_id=None, selected_location_id=None, rect=None):
        """Draw a location graph inside a panel using content-defined positions."""
        rect = rect or self.pg.Rect(24, 130, 620, 350)
        locations = world_map.locations()
        positions = {}
        for index, location in enumerate(locations):
            raw = location.position or (150 + index * 180, 220)
            positions[location.location_id] = (rect.x + 16 + raw[0], rect.y - 18 + raw[1])
        drawn = set()
        for location in locations:
            for neighbor in world_map.neighbors(location.location_id):
                edge = tuple(sorted((location.location_id, neighbor.location_id)))
                if edge in drawn:
                    continue
                self.map_edge(positions[location.location_id], positions[neighbor.location_id])
                drawn.add(edge)
        for location in locations:
            position = positions[location.location_id]
            self.map_node(
                position,
                selected=location.location_id == selected_location_id,
                current=location.location_id == current_location_id,
            )
            self.text(location.name, position[0] - 34, position[1] + 30, (235, 238, 245))
        return positions

    def error(self, message):
        self.panel(self.pg.Rect(24, self.height - 70, self.width - 48, 42), (88, 42, 48))
        self.text(message, 40, self.height - 60, (255, 220, 220))
